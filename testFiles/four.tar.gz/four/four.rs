/*fn main(let argc: i32, let argv: &str){
    println!("Rust compiled");
}*/

fn main(){
    println!("Rust compiled!");
}
